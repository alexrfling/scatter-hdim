# scatter
Interactive scatter plot with d3.js

![alt text](https://raw.githubusercontent.com/alexrfling/scatter/master/img/example.png)
